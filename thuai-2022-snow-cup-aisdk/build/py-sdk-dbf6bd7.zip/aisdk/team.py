from enum import IntEnum

class Team(IntEnum):
  RED = 0
  YELLOW = 1
  GREEN = 2