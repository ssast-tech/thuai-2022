#include "egg_sdk.h"
#include <iostream>

void update() {
  auto &game = thuai::GameState::instance();
  
  // your ride goes here
}